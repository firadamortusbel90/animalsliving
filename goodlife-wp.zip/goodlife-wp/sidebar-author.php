<aside class="sidebar small-12 medium-4 columns equal" role="complementary">
	<div class="sidebar_inner fixed-me">
	<?php 
	
		##############################################################################
		# Author Sidebar
		##############################################################################
	
	 	?>
	<?php dynamic_sidebar('author'); ?>
	</div>
</aside>