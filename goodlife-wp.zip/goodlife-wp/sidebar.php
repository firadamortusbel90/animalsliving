<aside class="sidebar small-12 medium-4 columns" role="complementary">
	<?php 
	
		##############################################################################
		# Display the asigned sidebar
		##############################################################################

	?>
	<?php dynamic_sidebar('blog'); ?>
</aside>