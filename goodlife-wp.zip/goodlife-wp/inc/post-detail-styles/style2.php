<?php
	$id = get_the_ID();
	$review_style = get_post_meta($id, 'post-review-style', true);
	$fixed = ot_get_option('article_fixed_sidebar', 'on'); 
?>
<div class="post post-header style3" data-stellar-background-ratio="0.92">
	<div>
		<div class="row children">
			<div class="small-12 medium-10 medium-centered columns">
				<header class="post-title entry-header text-center">
					<?php do_action( 'thb_DisplaySingleCategory', true); ?>
					<?php the_title('<h1 class="entry-title" itemprop="name headline">', '</h1>' ); ?>
					<?php do_action('thb_PostMeta', true, true, true, true, true ); ?>
				</header>
			</div>
		</div>
	</div>
</div>
<div class="row"<?php if ($fixed == 'on') { ?> data-equal=">.columns" data-row-detection="true"<?php } ?>>
	<div class="small-12 medium-8 columns">
		<?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
		  <article itemscope itemtype="http://schema.org/Article" <?php post_class('post blog-post'); ?> id="post-<?php the_ID(); ?>" role="article">
		  	<div class="share-container">
	  			<?php do_action('thb_social_article_detail_vertical', false, true, 'hide-for-small'); ?>
				  <div class="post-content-container">
						<div class="post-content entry-content cf">
							<?php if ($review_style !== 'style3') { do_action('thb_post_review' ); } ?>
				    	<?php the_content(); ?>
				    	<?php if ( is_single()) { wp_link_pages(); } ?>
						</div>
					</div>
				</div>
				<?php if ($review_style === 'style3') { do_action('thb_post_review' ); } ?>
				<?php get_template_part( 'inc/postformats/post-end' ); ?>
				<?php comments_template('', true); ?>
			</article>		
		<?php endwhile; else : endif; ?>	
  </div>
  <?php get_sidebar('single'); ?>
</div>
<?php if(ot_get_option('related_posts') !== 'off') { ?>
<div class="row">
  <div class="small-12 columns">
  	<?php get_template_part( 'inc/postformats/post-latest' ); ?>
  </div>
</div>
<?php } ?>