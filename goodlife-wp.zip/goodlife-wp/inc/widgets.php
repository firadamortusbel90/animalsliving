<?php
require get_template_directory() .'/inc/widgets/latest-posts-images.php';
require get_template_directory() .'/inc/widgets/shared-posts-images.php';
require get_template_directory() .'/inc/widgets/discussed-posts-images.php';
require get_template_directory() .'/inc/widgets/viewed-posts-images.php';
require get_template_directory() .'/inc/widgets/category-posts.php';
require get_template_directory() .'/inc/widgets/category-slider.php';
require get_template_directory() .'/inc/widgets/post-slider.php';
require get_template_directory() .'/inc/widgets/featured-video.php';
require get_template_directory() .'/inc/widgets/social-counters.php';
require get_template_directory() .'/inc/widgets/top-reviews.php';
require get_template_directory() .'/inc/widgets/single_ad.php';
require get_template_directory() .'/inc/widgets/multiple_ad_125.php';
?>